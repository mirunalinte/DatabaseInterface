-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: miruna
-- ------------------------------------------------------
-- Server version	8.1.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `discipline`
--

DROP TABLE IF EXISTS `discipline`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `discipline` (
  `idDisciplina` int NOT NULL AUTO_INCREMENT,
  `denumire` varchar(45) DEFAULT NULL,
  `numeProfesor` varchar(45) DEFAULT NULL,
  `prenumeProfesor` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`idDisciplina`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `discipline`
--

LOCK TABLES `discipline` WRITE;
/*!40000 ALTER TABLE `discipline` DISABLE KEYS */;
INSERT INTO `discipline` VALUES (1,'matematica','gauss','carl'),(2,'fizica','einstein','albert'),(3,'chimie','curie','marie'),(4,'engleza','shakespeare','william'),(5,'romana','eminescu','mihai'),(6,'geografie','columb','christopher'),(7,'desen','davinci','leonardo'),(8,'germana','goethe','johann'),(9,'franceza','verne','jules'),(10,'sport','bolt','usain'),(23,'ttt','llll','vvvv'),(24,'azi','acum','aici');
/*!40000 ALTER TABLE `discipline` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elevi`
--

DROP TABLE IF EXISTS `elevi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elevi` (
  `idElev` int NOT NULL AUTO_INCREMENT,
  `numeElev` varchar(45) DEFAULT NULL,
  `prenumeElev` varchar(45) DEFAULT NULL,
  `clasa` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`idElev`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elevi`
--

LOCK TABLES `elevi` WRITE;
/*!40000 ALTER TABLE `elevi` DISABLE KEYS */;
INSERT INTO `elevi` VALUES (1,'marinescu','marin','9'),(2,'ionescu','ion','10'),(3,'georgescu','george','11'),(4,'andreescu','andrei','12'),(5,'danescu','dan','9'),(6,'bogdanescu','bogdan','10'),(7,'iliescu','ion','11'),(8,'barbu','barbu','12'),(26,'ee','ee','ee'),(27,'miru','miru','14');
/*!40000 ALTER TABLE `elevi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `participare`
--

DROP TABLE IF EXISTS `participare`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `participare` (
  `idParticipare` int NOT NULL AUTO_INCREMENT,
  `idDisciplina` int DEFAULT NULL,
  `idElev` int DEFAULT NULL,
  `nota` int DEFAULT NULL,
  PRIMARY KEY (`idParticipare`),
  KEY `FK1_idx` (`idElev`),
  KEY `FK2_idx` (`idDisciplina`),
  CONSTRAINT `FK1` FOREIGN KEY (`idElev`) REFERENCES `elevi` (`idElev`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK2` FOREIGN KEY (`idDisciplina`) REFERENCES `discipline` (`idDisciplina`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `participare`
--

LOCK TABLES `participare` WRITE;
/*!40000 ALTER TABLE `participare` DISABLE KEYS */;
INSERT INTO `participare` VALUES (1,1,1,10),(2,1,1,10),(3,1,1,10),(8,1,1,6),(9,3,7,5),(10,5,1,8),(14,5,5,2),(15,2,4,8),(16,5,5,5),(22,4,3,5);
/*!40000 ALTER TABLE `participare` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-01 22:45:12
