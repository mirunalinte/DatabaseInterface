package tema2;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Elev {
	private final IntegerProperty idElev;
	private final StringProperty numeElev;
	private final StringProperty prenumeElev;
	private final StringProperty clasa;
	public Elev(Integer idElev, String numeElev, String prenumeElev, String clasa) {
		this.idElev = new SimpleIntegerProperty(idElev);
		this.numeElev = new SimpleStringProperty(numeElev);
		this.prenumeElev = new SimpleStringProperty(prenumeElev);
		this.clasa = new SimpleStringProperty(clasa);
	}
	public Integer getidElev() {
		return idElev.get();
	}
	public String getnumeElev() {
		return numeElev.get();
	}
	public String getprenumeElev() {
		return prenumeElev.get();
	}
	public String getclasa() {
		return clasa.get();
	}
	public void setidElev(Integer valoare) {
		idElev.set(valoare);
	}
	public void setnumeElev(String valoare) {
		numeElev.set(valoare);
	}
	public void setprenumeElev(String valoare) {
		prenumeElev.set(valoare);
	}
	public void setclasa(String valoare) {
		clasa.set(valoare);
	}
	public IntegerProperty idElevProperty() {
		return idElev;
	}
	public StringProperty numeElevProperty() {
		return numeElev;
	}
	public StringProperty prenumeElevProperty() {
		return prenumeElev;
	}
	public StringProperty clasaProperty() {
		return clasa;
	}
}