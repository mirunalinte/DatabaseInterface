package tema2;

import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Tab;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert;

public class tema2Controller implements Initializable {

	@FXML
	private TableColumn<Elev, String> atribut_clasa_E;

	@FXML
	private TableColumn<Disciplina, String> atribut_denumire_D;

	@FXML
	private TableColumn<Disciplina, Integer> atribut_idDisciplina_D;

	@FXML
	private TableColumn<Participare, Integer> atribut_idDisciplina_P;

	@FXML
	private TableColumn<Elev, Integer> atribut_idElev_E;

	@FXML
	private TableColumn<Participare, Integer> atribut_idElev_P;

	@FXML
	private TableColumn<Participare, Integer> atribut_idParticipare_P;

	@FXML
	private TableColumn<Participare, Integer> atribut_nota_P;

	@FXML
	private TableColumn<Elev, String> atribut_numeElev_E;

	@FXML
	private TableColumn<Disciplina, String> atribut_numeProfesor_D;

	@FXML
	private TableColumn<Elev, String> atribut_prenumeElev_E;

	@FXML
	private TableColumn<Disciplina, String> atribut_prenumeProfesor_D;

	@FXML
	private Button buton_AdaugaDisciplina_D;

	@FXML
	private Button buton_AdaugaElev_E;

	@FXML
	private Button buton_AdaugaParticipare_P;

	@FXML
	private Button buton_ModificaDisciplina_D;

	@FXML
	private Button buton_ModificaElev_E;

	@FXML
	private Button buton_ModificaParticipare_P;

	@FXML
	private Button buton_Refresh_D;

	@FXML
	private Button buton_Refresh_E;

	@FXML
	private Button buton_Refresh_P;

	@FXML
	private Button buton_StergeDisciplina_D;

	@FXML
	private Button buton_StergeElev_E;

	@FXML
	private Button buton_StergeParticipare_P;

	@FXML
	private TextField input_NumeElev_E;

	@FXML
	private TextField input_NumeProfesor_D;

	@FXML
	private TextField input_PrenumeElev_E;

	@FXML
	private TextField input_PrenumeProfesor_D;

	@FXML
	private TextField input_clasa_E;

	@FXML
	private TextField input_denumire_D;

	@FXML
	private TextField input_idDisciplina_P;

	@FXML
	private TextField input_idElev_P;

	@FXML
	private TextField input_nota_P;

	@FXML
	private Tab tab_Discipline;

	@FXML
	private Tab tab_Elevi;

	@FXML
	private Tab tab_Participare;

	@FXML
	private TableView<Disciplina> tabela_Discipline;

	@FXML
	private TableView<Elev> tabela_Elevi;

	@FXML
	private TableView<Participare> tabela_Participare;


	private ObservableList<Elev> dateElevi;
	private ObservableList<Disciplina> dateDiscipline;
	private ObservableList<Participare> dateParticipare;
	private DBOperations jb;

	@Override
	@FXML
	public void initialize(URL url, ResourceBundle rb) {
		jb = new DBOperations();
		try
		{
			jb.connect();
			dateDiscipline = FXCollections.observableArrayList();
			ResultSet rs = jb.vedeTabela("discipline");
			while (rs.next()) {
				dateDiscipline.add(new Disciplina(rs.getInt("idDisciplina"), rs.getString("denumire"), rs.getString("numeProfesor"), rs.getString("prenumeProfesor")));
			}
			atribut_idDisciplina_D.setCellValueFactory(new PropertyValueFactory<>("idDisciplina"));
			atribut_denumire_D.setCellValueFactory(new PropertyValueFactory<>("denumire"));
			atribut_numeProfesor_D.setCellValueFactory(new PropertyValueFactory<>("numeProfesor"));
			atribut_prenumeProfesor_D.setCellValueFactory(new PropertyValueFactory<>("prenumeProfesor"));

			tabela_Discipline.setItems(null);
			tabela_Discipline.setItems(dateDiscipline);
			jb.disconnect();
			
		}
		catch (Exception e)
		{
			System.err.println(e.getMessage());        
		}

		try
		{
			jb.connect();
			dateElevi = FXCollections.observableArrayList();
			ResultSet rs = jb.vedeTabela("elevi");
			while (rs.next()) {
				dateElevi.add(new Elev(rs.getInt("idElev"), rs.getString("numeElev"), rs.getString("prenumeElev"), rs.getString("clasa")));
			}
			atribut_idElev_E.setCellValueFactory(new PropertyValueFactory<>("idElev"));
			atribut_numeElev_E.setCellValueFactory(new PropertyValueFactory<>("numeElev"));
			atribut_prenumeElev_E.setCellValueFactory(new PropertyValueFactory<>("prenumeElev"));
			atribut_clasa_E.setCellValueFactory(new PropertyValueFactory<>("clasa"));

			tabela_Elevi.setItems(null);
			tabela_Elevi.setItems(dateElevi);
			jb.disconnect();

		}
		catch (Exception e)
		{
			System.err.println(e.getMessage());
		}

		try
		{
			jb.connect();
			dateParticipare = FXCollections.observableArrayList();
			ResultSet rs = jb.vedeTabela("participare");
			while (rs.next()) {
				dateParticipare.add(new Participare(rs.getInt("idParticipare"), rs.getInt("idElev"), rs.getInt("idDisciplina"), rs.getInt("nota")));
			}
			atribut_idParticipare_P.setCellValueFactory(new PropertyValueFactory<>("idParticipare"));
			atribut_idElev_P.setCellValueFactory(new PropertyValueFactory<>("idElev"));
			atribut_idDisciplina_P.setCellValueFactory(new PropertyValueFactory<>("idDisciplina"));
			atribut_nota_P.setCellValueFactory(new PropertyValueFactory<>("nota"));

			tabela_Participare.setItems(null);
			tabela_Participare.setItems(dateParticipare);
			jb.disconnect();

		}
		catch (Exception e)
		{
			System.err.println(e.getMessage());
		}
	}

	@FXML
	private void refreshDiscipline() throws SQLException, Exception {
		jb.connect();
		
		dateDiscipline = FXCollections.observableArrayList();
		ResultSet rs = jb.vedeTabela("Disciplina");
		while (rs.next()) {
			dateDiscipline.add(new Disciplina(rs.getInt("idDisciplina"), rs.getString("denumire"), rs.getString("numeProfesor"), rs.getString("prenumeProfesor")));
		}
		
		atribut_idDisciplina_D.setCellValueFactory(new PropertyValueFactory<>("idDisciplina"));
		atribut_denumire_D.setCellValueFactory(new PropertyValueFactory<>("denumire"));
		atribut_numeProfesor_D.setCellValueFactory(new PropertyValueFactory<>("numeProfesor"));
		atribut_prenumeProfesor_D.setCellValueFactory(new PropertyValueFactory<>("prenumeProfesor"));

		
		tabela_Discipline.setItems(null);
		tabela_Discipline.setItems(dateDiscipline);
		jb.disconnect();
	}


	@FXML
	private void adaugaDisciplina() throws SQLException, Exception {
		jb.connect();
		String denumire = input_denumire_D.getText();
		String numeProfesor = input_NumeProfesor_D.getText();
		String prenumeProfesor = input_PrenumeProfesor_D.getText();

		
		jb.adaugaDisciplina(denumire, numeProfesor, prenumeProfesor);
		jb.disconnect();
	}

	@FXML
	private void refreshElevi() throws SQLException, Exception {
		jb.connect();
		dateElevi = FXCollections.observableArrayList();
		ResultSet rs = jb.vedeTabela("Elevi");
		while (rs.next()) {
			dateElevi.add(new Elev(rs.getInt("idElev"), rs.getString("numeElev"), rs.getString("prenumeElev"), rs.getString("clasa")));
		}
		atribut_idElev_E.setCellValueFactory(new PropertyValueFactory<>("idElev"));
		atribut_numeElev_E.setCellValueFactory(new PropertyValueFactory<>("numeElev"));
		atribut_prenumeElev_E.setCellValueFactory(new PropertyValueFactory<>("prenumeElev"));
		atribut_clasa_E.setCellValueFactory(new PropertyValueFactory<>("clasa"));

		tabela_Elevi.setItems(null);
		tabela_Elevi.setItems(dateElevi);
		jb.disconnect();
	}


	@FXML
	private void adaugaElev() throws SQLException, Exception {
		jb.connect();
		String numeElev = input_NumeElev_E.getText();
		String prenumeElev = input_PrenumeElev_E.getText();
		String clasa = input_clasa_E.getText();

		
		jb.adaugaElev(numeElev, prenumeElev, clasa);
		jb.disconnect();
	}

	@FXML
	private void refreshParticipare() throws SQLException, Exception {
		jb.connect();
		dateParticipare = FXCollections.observableArrayList();
		ResultSet rs = jb.vedeTabela("Participare");
		while (rs.next()) {
			dateParticipare.add(new Participare(rs.getInt("idParticipare"), rs.getInt("idElev"), rs.getInt("idDisciplina"), rs.getInt("nota")));
		}
		atribut_idParticipare_P.setCellValueFactory(new PropertyValueFactory<>("idParticipare"));
		atribut_idElev_P.setCellValueFactory(new PropertyValueFactory<>("idElev"));
		atribut_idDisciplina_P.setCellValueFactory(new PropertyValueFactory<>("idDisciplina"));
		atribut_nota_P.setCellValueFactory(new PropertyValueFactory<>("nota"));

		tabela_Participare.setItems(null);
		tabela_Participare.setItems(dateParticipare);
		jb.disconnect();
	}


	@FXML
	private void adaugaParticipare() throws SQLException, Exception {
		jb.connect();
		Integer idElev = Integer.parseInt(input_idElev_P.getText());
		Integer idDisciplina = Integer.parseInt(input_idDisciplina_P.getText());
		Integer nota = Integer.parseInt(input_nota_P.getText());
		
		jb.adaugaParticipare(idElev, idDisciplina, nota);
		jb.disconnect();
	}

	@FXML
	private void stergeElev() throws SQLException, Exception{
		jb.connect();
		Integer myIndex = tabela_Elevi.getSelectionModel().getSelectedIndex();
		Integer id = Integer.parseInt(String.valueOf(tabela_Elevi.getItems().get(myIndex).getidElev()));

		try 
		{
			
			jb.stergeTabela("elevi", "idElev", id);
			jb.disconnect();
		} 
		catch (Exception e)
		{
			System.out.println("Error!");
		}
	}

	@FXML
	private void stergeDisciplina() throws SQLException, Exception{
		jb.connect();
		Integer myIndex = tabela_Discipline.getSelectionModel().getSelectedIndex();
		Integer id = Integer.parseInt(String.valueOf(tabela_Discipline.getItems().get(myIndex).getidDisciplina()));

		try 
		{
			
			jb.stergeTabela("discipline", "idDisciplina", id);
			jb.disconnect();
		} 
		catch (Exception e)
		{
			System.out.println("Error!");
		}
	}

	@FXML
	private void stergeParticipare() throws SQLException, Exception{
		jb.connect();
		Integer myIndex = tabela_Participare.getSelectionModel().getSelectedIndex();
		Integer id = Integer.parseInt(String.valueOf(tabela_Participare.getItems().get(myIndex).getidParticipare()));

		try 
		{
			
			jb.stergeTabela("participare", "idParticipare", id);
			jb.disconnect();
		} 
		catch (Exception e)
		{
			System.out.println("Error!");
		}
	}

	@FXML
	private void modificaElev() throws SQLException, Exception{
		try {
			jb.connect();
			Elev item = tabela_Elevi.getSelectionModel().getSelectedItem();
			Integer idElev_nou = item.getidElev();
			String[] valori = {input_NumeElev_E.getText(), input_PrenumeElev_E.getText(), input_clasa_E.getText()};
			String[] campuri = {"input_NumeElev_E", "input_PrenumeElev_E", "input_clasa_E"};
			jb.modificaTabela("elevi", "idElev", idElev_nou, campuri, valori);
			Stage stage = (Stage)
			input_NumeElev_E.getScene().getWindow();
			stage.close();
		} catch(Exception e) {
			System.out.println("Error!");
			return;
		}
		jb.disconnect();		 
	}
	
	@FXML
	private void modificaDisciplina() throws SQLException, Exception{
		try {
			jb.connect();
			Disciplina item = tabela_Discipline.getSelectionModel().getSelectedItem();
			Integer idDisciplina_nou = item.getidDisciplina();
			String[] valori = {input_denumire_D.getText(), input_NumeProfesor_D.getText(), input_PrenumeProfesor_D.getText()};
			String[] campuri = {"input_denumire_D", "input_NumeProfesor_D", "input_PrenumeProfesor_D"};
			jb.modificaTabela("discipline", "idParticipare", idDisciplina_nou, campuri, valori);
			Stage stage = (Stage)
			input_NumeElev_E.getScene().getWindow();
			stage.close();
		} catch(Exception e) {
			System.out.println("Error!");
			return;
		}
		jb.disconnect();		 
	}
	
	@FXML
	private void modificaParticipare() throws SQLException, Exception{
		try {
			jb.connect();
			Participare item = tabela_Participare.getSelectionModel().getSelectedItem();
			Integer idParticipare_nou = item.getidParticipare();
			String[] valori = {input_idElev_P.getText(), input_idDisciplina_P.getText(), input_nota_P.getText()};
			String[] campuri = {"input_idElev_P", "input_idDisciplina_P", "input_nota_P"};
			jb.modificaTabela("participare", "idParticipare", idParticipare_nou, campuri, valori);
			Stage stage = (Stage)
			input_idElev_P.getScene().getWindow();
			stage.close();
		} catch(Exception e) {
			System.out.println("Error!");
			return;
		}
		jb.disconnect();		 
	}
}
