package tema2;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Participare {
	private final IntegerProperty idParticipare;
	private final IntegerProperty idElev;
	private final IntegerProperty idDisciplina;
	
	private final IntegerProperty nota;
	public Participare(Integer idParticipare, Integer idElev, Integer idDisciplina, Integer nota) {
		this.idParticipare = new SimpleIntegerProperty(idParticipare);
		this.idElev = new SimpleIntegerProperty(idElev);
		this.idDisciplina = new SimpleIntegerProperty(idDisciplina);
		this.nota = new SimpleIntegerProperty(nota);		
	}
	public Integer getidParticipare() {
		return idParticipare.get();
	}
	public Integer getidElev() {
		return idElev.get();
	}
	public Integer getidDisciplina() {
		return idDisciplina.get();
	}
	public Integer getnota() {
		return nota.get();
	}
	public void setidParticipare(Integer valoare) {
		idParticipare.set(valoare);
	}
	public void setidElev(Integer valoare) {
		idElev.set(valoare);
	}
	public void setidDisciplina(Integer valoare) {
		idDisciplina.set(valoare);
	}
	public void setnota(Integer valoare) {
		nota.set(valoare);
	}
	public IntegerProperty idParticipareProperty() {
		return idParticipare;
	}
	public IntegerProperty idElevProperty() {
		return idElev;
	}
	public IntegerProperty idDisciplinaProperty() {
		return idDisciplina;
	}
	public IntegerProperty notaProperty() {
		return nota;
	}
}