package tema2;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Disciplina {
	private final IntegerProperty idDisciplina;
	private final StringProperty denumire;
	private final StringProperty numeProfesor;
	private final StringProperty prenumeProfesor;
	public Disciplina(Integer idDisciplina, String denumire, String numeProfesor, String prenumeProfesor) {
		this.idDisciplina = new SimpleIntegerProperty(idDisciplina);
		this.denumire = new SimpleStringProperty(denumire);
		this.numeProfesor = new SimpleStringProperty(numeProfesor);
		this.prenumeProfesor = new SimpleStringProperty(prenumeProfesor);
	}
	public Integer getidDisciplina() {
		return idDisciplina.get();
	}
	public String getdenumire() {
		return denumire.get();
	}
	public String getnumeProfesor() {
		return numeProfesor.get();
	}
	public String getprenumeProfesor() {
		return prenumeProfesor.get();
	}
	public void setidDisciplina(Integer valoare) {
		idDisciplina.set(valoare);
	}
	public void setdenumire(String valoare) {
		denumire.set(valoare);
	}
	public void setnumeProfesor(String valoare) {
		numeProfesor.set(valoare);
	}
	public void setprenumeProfesor(String valoare) {
		prenumeProfesor.set(valoare);
	}
	public IntegerProperty idDisciplinaProperty() {
		return idDisciplina;
	}
	public StringProperty denumireProperty() {
		return denumire;
	}
	public StringProperty numeProfesorProperty() {
		return numeProfesor;
	}
	public StringProperty prenumeProfesorProperty() {
		return prenumeProfesor;
	}
}